DECLARE
  v_max_id        NUMBER;
  v_max_total_id  NUMBER;
BEGIN
  -- Get current max values
  SELECT NVL(MAX(COUNTRY_ID),0), NVL(MAX(COUNTRY_TOTAL_ID),52800)
    INTO v_max_id, v_max_total_id
    FROM MIAZE.COUNTRIES;

  -- Insert next 10 rows
  FOR i IN 1..10 LOOP
    INSERT INTO MIAZE.COUNTRIES (COUNTRY_ID, COUNTRY_TOTAL_ID, COUNTRY_NAME)
    VALUES (
      v_max_id + i,                 -- Next COUNTRY_ID
      v_max_total_id + i,           -- Next COUNTRY_TOTAL_ID
      'Country' || (v_max_id + i)  -- Country name
    );
  END LOOP;

  COMMIT;
END;
/